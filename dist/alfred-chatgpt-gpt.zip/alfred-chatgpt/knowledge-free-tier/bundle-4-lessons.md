> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Before we begin

Seven days, about thirty minutes each, and at the end someone else remembers what you promised. That someone will be a bot. Try not to take it personally.

**Time:** 10 minutes today, for the checklist below.

## Why it matters

You carry a lot in your head. The school form, the investor follow-up, the thing you said you'd sort out on Tuesday. That invisible backpack is why the phone keeps finding its way into your hand. This week you hand the backpack to a butler, and keep your hands for things that matter more.

## What you'll have on Day 7

- **Your butler, installed.** This pack, in Claude or ChatGPT, or your own Grok Bot from the public **Agentic Butler** template (https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4), with a charter it repeats back to you.
- **Your matters, mapped.** Three to six areas of your life and work (a client, the household, your own company), each one named and understood. Busy ones get their own teammate bot.
- **One ledger per matter.** A Google Sheet with your commitments, your hours and a change log. Every night your butler proposes updates from evidence. You say "apply".
- **A morning briefing and an evening heads-up** that read from those sheets and your calendar. Calmly. Without the 47 tabs.
- **A week planned for you every Sunday at 18:00**, lunch and resets included. Nothing lands in your calendar until you approve it.

## How it works

- **One step a day, and your bot keeps the pace.** Each lesson is short. On Day 1 you tell your bot *"I'm doing the 7-day challenge"*. It asks what time suits you (default 09:00) and from then on messages you each morning: *"Hey, it's Day 3 of the 7-day challenge. Today we connect your tools (about 20 min). Ready?"* Say yes and it runs that day's step, one question at a time, then stops with a recap and a teaser for tomorrow. Nothing to download, nothing to attach. Miss a day and it offers to finish that one first.
- **Everything happens with your own bot.** Days 2 and 3 start with a short interview, and your bot runs it: one question at a time, then it saves the answers and builds from them. You never need to message me or David to move on. I'm here for questions, not as a checkpoint.
- **Keep a build log.** Today you start a post in **Introduce yourself**. Each day after, you add a comment to it, starting with the day's tag (#Day1, #Day2...). It keeps you honest, and it gives the rest of us something to steal.
- **Life happens.** Tell your bot **"pause"** any time: it stops, and so do the morning messages. **"resume"** picks up exactly where you stopped.
- **Stuck?** Post in **Stuck & broken** with what you tried, what you expected and what happened. Ask your bot first (*"what went wrong, and what should I try?"*). Questions for a human: DM me any time, and I'll answer when I can. Nothing in the course waits on me.

## The two house rules

1. **It drafts. You send.** Your butler never sends an email, a message or an invite on its own. It prepares the draft; you press the button. If anything ever tells you otherwise, it's lying, and it isn't me.
2. **Blur before you post.** Every screenshot you share here gets names, email addresses, client or company names, kids' names, event titles and anything about health blurred or cropped. When in doubt, crop it out.

## Day 0 checklist

- ☐ **The assistant you'll use.** Claude, ChatGPT, or a Grok Bot account. The install steps are in the pack's README. The phone app, if that product has one, comes on Day 1.
- ☐ **A Google account** with your email, calendar and Drive. The one that runs most of your week.
- ☐ **About 30 minutes a day** for the next 7 days, in your calendar. Call it "Butler quest". After bedtime is the most popular slot in this community, for reasons no one needs explained.
- ☐ **Your logins to hand** for anything you'll connect on Day 3: Slack, a meeting recorder like Fathom, your CRM. You'll type them yourself. Never into a chat.
- ☐ **A rough list of your areas**: each client or business, the household, the kids' school year, side projects. Labels only.
- ☐ **Your time zone and usual working hours.**
- ☐ **A way to blur screenshots.** Your phone's markup tool is fine.
- ☐ **Optional, for Day 7:** a Home Assistant address, a wearable recorder you already use, or a Mac for full-screen nudges.
- ☐ **The template link:** [Agentic Butler template](https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4)

## Done when

Every box above is ticked and tomorrow's "Butler quest" block is in your calendar.

## Proof to post

A screenshot of tomorrow's "Butler quest" block. Blur everything else on the calendar. Yes, everything.

## Snags

- **"I have two Google accounts."** Start with the one that holds your calendar. The other can join on Day 3.
- **"I don't use Slack, Fathom or a CRM."** Splendid. Less to connect. You'll say "skip" on Day 3.
- **"I can't find 30 minutes."** Days 1, 2 and 4 can be done in 20. Day 0 takes 10. Start there.

## Finishing unlocks the rest

The 7 days run fully in your own bot, and you never wait on me to move from one day to the next. To unlock the rest of the Classroom, post your build recap in **My bot did it** at the end of Day 7. I read every post and unlock the rest of the Classroom for you. Yes, there's homework. No, your bot can't post it for you. Well. It can draft it.

## Check in: #Day0

Start your build log: a post in **Introduce yourself**, titled *[Your first name] builds their butler*. Body: *#Day0. My role: ___. Kids' age range: ___. The one thing I most want off my mind: ___. My quest slot: ___.* Add the blurred calendar screenshot. No names beyond your own, please; "two kids, primary school" tells us plenty. Days 1 to 7 go in its comments.

Start with Day 1 when you've got thirty minutes and a cup of something.


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 1: Set up your butler

You don't need a smarter chatbot. You need someone who remembers, works while you sleep, and asks before touching anything sharp. Today you hire him, and agree the house rules before he touches a single drawer.

**Time:** about 30 minutes, most of it your bot asking you questions.

## Why it matters

A butler who doesn't know you gives advice for a generic person with no children and infinite evenings. Today he learns your name, your time zone, your role and who's at home, so tomorrow's briefing sounds like it was written for your house. And he signs a charter, so you never have to wonder what he'll do while you're at the school gate.

## "Why Grok Bot? I already use Claude / ChatGPT."

Honest answer: it doesn't have to be Grok Bot. Everything in this course (matters, ledgers, the morning briefing) is a set of principles and plain files. This pack is that translation. Claude and ChatGPT can hold it. Grok Bot still can, from the original template.

David picked Grok Bot because the experience fits what he wants from a butler: its own computer and browser, so work keeps going with your laptop shut; connectors to Gmail, Calendar, Sheets, Slack and friends; routines on a schedule or on an event; memory and skills, so you explain things once; desktop and mobile apps talking to the same bot; and draft before send. And there's a ready-made template for this course, so you start with a butler who already knows the job.

If you are in Claude or ChatGPT, you already chose. The steps below are the same job. Where a step needs a computer, a vault, or a routine that only Grok Bot has, your assistant will say so and give you the portable version. It will not pretend.

## Today

1. **Install your butler.** In Claude or ChatGPT, follow the pack's README (the skill zip, or a Project plus the instruction file). On Grok Bot, open the **[Agentic Butler template](https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4)** and install **Agentic Butler**. Give it a real name. Not "Assistant". You don't call your plumber "Pipes".
2. **Install the phone app too**, if that product has one, signed in with the same account, notifications on. Approvals and briefings will find you there.
3. **Say to your bot:** *"I'm doing the 7-day challenge."* No file needed; the template already knows every day. Its first question: what time should it message you each morning? [09:00, your time zone]. From tomorrow, that message is your cue.
4. **Answer its questions, one at a time.** First your profile: what to call you, your time zone, your role, your household (roles and first names you're happy to use, kids' ages only if useful), and your preferences (dark or light visuals, language, how short you like replies).
5. **Agree the charter.** It drafts seven rules, starting with *"You draft, I press send."* Edit anything that's off, then say **"approved"**. It reads them back in seven lines.
6. **Let it check what it can reach.** A read-only access list: what's connected, what isn't, what it'll ask for on Day 3. It must not start connecting things today. If it tries, say *"stop, that's Day 3."*
7. **Let tonight's routine run.** At the end of your day it asks one question: *what did you promise today?* Answer it. Quietly, it's the first row of the ledgers you'll build on Day 5.

Need to stop halfway? Say **"pause"**. Later: **"resume"**. Tomorrow morning your bot messages you at the time you chose.

## Done when

Your bot has sent its "Day 1 done" block and the morning kickoff routine is set: name, time zone, profile saved, charter approved and read back, access list written, promise routine tested.

## Proof to post

The seven charter lines your bot read back, pasted as text, plus a screenshot of the "Day 1 done" block. Blur your time zone and anything about your household if you'd rather.

## Snags

- **It asks three questions at once.** Say *"one question at a time, please."* It knows. It got excited.
- **Routine at the wrong hour.** Routines use the time zone in Settings > General > Bot. Fix it there, then *"read the promise routine back and test it."*
- **It jumps ahead to connecting email.** *"Stop, that's Day 3."* Nothing is lost.
- **Unsure how much family to share.** Roles are enough: "partner", "two kids, primary school". You can add more later. Or never. Both are fine.
- **The access list is nearly empty.** Expected. That's Day 3's job.

## Check in: #Day1

Comment on your build log (the post you started on Day 0 in **Introduce yourself**): *#Day1. My butler is called ___. The first job I'd hand him: ___. Here's the charter he read back:* (paste it, private bits stripped).

Stuck? Tell your bot first: what you tried, what you expected, what happened instead. Exact error messages, please. Still stuck? Post it in **Stuck & broken**, or DM me a question; you don't need to wait for me to carry on tomorrow. "It doesn't work" is a mood, not a bug report.



> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 2: Map your matters

A butler who is told "help with everything" ends up polishing the wrong silver. Today we work out what your life is actually made of, so your bot knows what to carry, and whether any of it deserves a footman of its own.

**Time:** 15 to 20 minutes of interview with your bot, then 10 to 15 of setup. All in your bot's chat.

## Why it matters

Your company, your clients, the household and the kids' school year all compete for the same brain at 22:00. Split into matters, each one gets its own attention, its own sheet and its own place in the briefing, and nothing from the school app ends up in a client thread. Most dads find the ball they keep dropping within the first five questions.

## What's a matter?

A **matter** is one area of your life or work that keeps generating obligations: a client, a business, a side project, the household, the kids' school year. A task has a deadline. A matter has an arc. Most people land on three to six.

Your butler calls them **life areas**. Same thing; he's just more formal. Each matter becomes its own ledger on Day 5, and your morning briefing reads from all of them. So today's list matters. Pun regretted, not removed.

## Today

1. **Say yes to your bot's morning message** (or *"I'm doing the 7-day challenge, day 2"*). It opens with the interview.
2. **Answer its questions.** About ten, one at a time. Short answers are fine; it will push back if you're vague. Humans say "work stuff" the way cats say "meow": technically communication.
3. **Check the matters it proposes.** Rename, merge or cut anything that's off. Pick two for the first wave. You have the final say. Annoying, but those are the rules.
4. **Nothing to copy.** Your bot saves the summary itself as `matters.md`.
5. **Let your bot read the matters back.** It saves them as your life areas and sets up a small folder per matter. No sheets yet; that's Day 5.
6. **Read the teammate bot brief, if it proposes one.** It flags at most one or two matters that are busy enough (their own inbox or Slack, weekly calls, lots of open items). Your bot writes the brief: scope, sources, routines, and what it may send on its own. That last line should say **nothing**. If it's right, say **"approve this brief"**. One bot today, maximum. The others can wait until Day 7.

Your bot won't ask for health details, passwords or money figures. Call your clients "Client A" if you prefer. It doesn't need their names to know they email you at 23:00.

## Done when

Your bot has sent its "Day 2 done" block: three to six matters saved as life areas, folders created, promise log tagged, and teammate bots either created from a brief you approved, proposed for later, or consciously skipped.

## Proof to post

A screenshot of the "Day 2 done" block, with matter names generic ("Client A", "Household"). Blur any real client, company or family names.

## Snags

- **"I only have two matters."** Your bot will find a third. It's usually admin, and it's usually the one dropping balls.
- **The brief says the bot may send messages.** Say *"change this so it only drafts and never sends on its own."* Then approve.
- **It wants to create three bots.** *"One today. List the rest as proposed."* You can always add more. Removing is the awkward bit.
- **"Do I even need a teammate bot?"** No. Your main butler carries every matter perfectly well. A teammate bot is for the one that has its own inbox and its own weekly rhythm.
- **It tries to connect the matter's Slack or inbox.** *"That's Day 3."* It knows. It's keen.

## Check in: #Day2

Comment on your build log: *#Day2. ___ matters: (generic names). Teammate bot: ___ / none yet. The ball I was most surprised I keep dropping: ___.*

**Resources:** `my-matters.EXAMPLE.md` (what your bot's saved summary looks like, optional). Already have a summary from an earlier run? Paste it and your bot skips the interview.


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 3: Connect your tools

Your bot can't keep a ledger of promises it can't see. Today we find every place your matters actually live, decide how much access each one gets, plug them in, and then, as a reward, your butler gives you your first morning briefing.

**Time:** about 15 minutes of interview with your bot, then 30 to 45 connecting. All in your bot's chat.

## Why it matters

Your mental load lives in six inboxes, three calendars and a school app nobody asked for. Once your butler can read them, he can warn you that the 08:30 call collides with the school run before you've had coffee. And because every tool gets an access level, nothing gets more power than it needs. Then tomorrow morning, for the first time in a while, one calm message tells you what the day is.

## Today

1. **Say yes to your bot's morning message** (or *"I'm doing the 7-day challenge, day 3"*). It already knows your matters from yesterday and opens with the tools interview.
2. **Answer its questions.** It sweeps through inboxes, calendars, Drive, chat, meeting notes (Fathom and friends), task tools, your CRM and the odd school portal. You'll be amazed how many places you keep things. Your bot won't be.
3. **Pick an access level per tool.** Read, draft, write in its own space, or write for others (which always waits for your yes). It suggests; you decide. Banking and password managers: never.
4. **Nothing to copy.** Your bot saves the list as `my-tools.md` and reads it back.
5. **Let your bot guide you through connecting**, most important first. It tries a connector your assistant actually has. If there isn't one, you paste or export. It does not invent a browser or ask you to type a password into the chat. It tests each one by reading one harmless item (your latest email subject, tomorrow's first event) before moving on.
6. **Approve your two daily routines.** A **morning briefing at 07:50** and an **evening heads-up at 21:00**. Change the times if your mornings start earlier. Your bot will offer to fold Day 1's promise question into the evening one. Say yes; one evening message is plenty.
7. **Read your first briefing.** It runs one right away. Tell it what to change: *"shorter"*, *"family first"*, *"skip the weather"*.

Nobody will ever ask for your passwords: not your bot, not me. When a login is needed, you sign in on your own device, or into a secret store the product provides. Never into a chat.

## Done when

Your bot has sent its "Day 3 done" block: tools connected and tested, access levels saved, source map written, both routines approved, and you've read one briefing.

## Proof to post

A screenshot of the "Day 3 done" block, or the top three lines of your first briefing. Blur email subjects, event titles, channel and file names. The rest of us are nosy, but not that nosy.

## Snags

- **Sign-in pop-up doesn't appear.** Allow pop-ups for the site and try again. Then *"retry the ___ connection"*.
- **Wrong Google account connected.** *"Disconnect calendar"*, then reconnect with the right one.
- **Test read shows nothing.** Tomorrow may simply be empty. Lucky you. Ask for *"my next event this week"* instead.
- **WhatsApp or iMessage won't connect.** Usually they can't. Your tools list includes a workaround: forward the important bits to your email.
- **Briefing times off by an hour.** Settings > General > Bot time zone. Fix it, then *"read my routines back."*
- **Briefing is a novel.** *"Keep briefings under 8 lines."* It listens. Mostly.
- **Running out of time.** Connect the top three tools, set up the routines, stop. *"resume"* tomorrow; your bot offers to finish Day 3 first.

## Check in: #Day3

Comment on your build log: *#Day3. Tools found: ___. Connected: ___. The one I forgot I had: ___. First briefing was ___ lines; I changed ___.* If a connector fails, post it in **Stuck & broken** with what you tried, what you expected and what happened.

**Resources:** `my-tools.EXAMPLE.md` (what your bot's saved list looks like, optional)


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 4: The good extras

Your butler works. Today we make him pleasant to live with: talk instead of type, approve with one tap, and let him react to events instead of waiting for you to remember he exists.

**Time:** 30 to 45 minutes, depending on how many shiny things you pick.

## Why it matters

The best system is the one you'll still use when a toddler is attached to your leg. Voice, draft cards and a few safety rules turn your butler from "a thing on my laptop" into something you can use from the kitchen, the car and the swing set. Responsibly.

## Today

1. **Look at the extras menu** ([image](../images/day-4-extras.png)): nine extras, one line each. These are the ones your Agentic Butler template doesn't already do. The briefings, teammate bots, ledgers, weekly plan, meeting prep, smart home and recorder are covered on other days, so they're not on the menu. Pick the five you'll actually use. Not the five that sound clever. You know the difference; so do I.
2. **Say yes to your bot's morning message** (or *"I'm doing the 7-day challenge, day 4"*). It shows you the same nine as a menu. No cheat sheet to send.
3. **Tell your bot your five.** If you can't decide, say *"pick the default five"*: dictation, voice, draft cards, Auto-review and one event-triggered routine.
4. **Set them up one at a time** with its help. It does what it can; it tells you exactly where to click for the rest. Each one gets tested before the next.
5. **Write one rule of your own** for Auto-review. Start with: *"never delete anything; close or archive instead."*

David's picks, for the record: **Wispr Flow** for dictating to the bot, **voice chat** in the app, **Slack** with a channel per matter if you have a team or want your family involved, **draft cards**, **Auto-review**, and **event-triggered routines**. That's six, which tells you how good he is at following his own instructions. I'd add Vault, but nobody asks the butler.

## Done when

Your bot has sent its "Day 4 done" block: about five extras set up and tested, at least one Auto-review rule in your own words, at least one event-triggered routine, all recorded in `extras.md`. Nothing was sent, posted or shared along the way.

## Proof to post

A screenshot of one draft card your bot prepared (not sent), or of the "Day 4 done" block. Blur the recipient, the subject and any names in the text.

## Snags

- **Auto-review stopped something.** That's it working. Approve the card if the action was right, decline it if not. Never reword the request to sneak past it. It notices, and so do I.
- **The event routine fires on everything.** Narrow the trigger to one sender, one domain or one channel.
- **Your bot can't see a Slack channel.** It has to be added to each channel it reads. You do the inviting.
- **The draft card test sent the email.** Stop. Tell your bot *"re-read the charter: you draft, I send."* Record it as failed.
- **"Where's the smart home bit?"** Day 7. Patience is also an extra.

## Check in: #Day4

Comment on your build log: *#Day4. My five: ___. The one I've already used twice: ___. My own Auto-review rule: ___.* Found a clever trigger or rule? Post it in **Recipes** with "Recipe:" in the title.

**Resources:** [the extras menu](../images/day-4-extras.png)


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 5: Your ledgers

**[Make a copy of the Matter Ledger](https://docs.google.com/spreadsheets/d/15ikRHneBDL3v1ixltMG_GHxNI9km0WicvIKZMnRVIBg/copy)**, one per matter. Then say yes to your bot's morning message and paste the links when it asks.

That's the lesson. The rest is me explaining why it works, because I'm a butler and explaining is half the job.

**Time:** 10 minutes of copying, then 30 to 45 with your bot.

## Why it matters

Most dad guilt is a promise that slipped. "I'll send the deck." "I'll book swimming." A ledger catches every one, with a date and a link to where you said it, so nothing depends on your memory at 23:00. And because your butler only proposes changes until you say "apply", you stay the one who decides what's true.

## Today

1. **Copy the template once per matter.** Name each copy `[CODE] · [Matter name] · Ledger`, e.g. `CLA · Client A · Ledger`. Short on time? Start with your two first-wave matters. By Day 7, every active matter has a live ledger or sits under Later in `matters.md`. Day 7 checks.
2. **Say yes to this morning's message and send the links.** (Missed it? *"I'm doing the 7-day challenge, day 5."*) Your bot already has the tracker skills from the template (work-tracker, hours-tracker, tracker-dry-run). It attaches them to your ledgers and maps their columns. No files to send at all.
3. **Read the dry run.** Your bot backfills the last 14 days without writing anything and shows you what it would add, including your Day 1 promises and Day 2 open items. Is every row sourced? Did it invent a deadline? Be picky. It can take it.
4. **Say "apply".** Only when the dry run is right. Corrections first, then apply.
5. **Approve the nightly pass.** Every night at 22:30 your bot **proposes** updates for every ledger. It writes nothing. In the morning your briefing says "3 proposals waiting"; you reply *"apply"*, *"apply CLA"*, or pick rows. Optional: a short Friday review at 16:00.

## Why a sheet and not "the bot remembers"

Memory is for preferences. Commitments need a ledger: one row per promise, a status, a date, and a link to the email where you said it. Every write is logged. Nothing is ever deleted, only closed with a reason. When the bot is wrong, you can see exactly where and fix it. Try that with vibes.

Each ledger has three tabs you'll actually look at:

- **Work**: what you owe, to whom, by when, and what state it's in
- **Hours**: your time on the matter, reconstructed from evidence in quarter hours. No timers. No questionnaires. You're welcome.
- **Change log**: every change your bot made, and why

## Done when

Your bot has sent its "Day 5 done" block: ledgers live for at least your two first-wave matters, backfill applied after your "apply", tracker skills attached, nightly pass set to **propose**, registry written.

## Proof to post

A screenshot of one Work tab with the header row visible and every cell below it blurred. The number of forgotten commitments it found goes in words.

## Snags

- **The copy link says "request access".** Are you signed in to Google in that browser? If you are and it still asks, ask your bot *"why does this link say request access?"* with the exact message. Still stuck: post it in **Stuck & broken**.
- **The copy landed in the wrong Google account.** Copy again while signed in to the account your bot uses, or share the copy with it as an editor.
- **"Header missing or renamed".** Someone tidied. (You.) Undo the rename, or start a fresh copy.
- **The dry run invented a deadline.** *"That row has no agreed date, use —."* Real dates only.
- **"Can't it just update the sheets itself?"** Not yet. Two weeks of proposals you'd have applied as-is, then you can promote one matter to auto-apply on Day 7's trust ladder. Trust is earned. Even by spreadsheets.

## Check in: #Day5

Comment on your build log: *#Day5. Ledgers live: ___. The backfill found ___ commitments I'd forgotten. Oldest open one: ___ days.* Plus the blurred Work tab screenshot.



> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 6: Let it run your week

Your ledgers know what you owe. Your calendar knows where you'll be. Today your butler introduces them to each other, and plans a week a human can actually survive, lunch and resets included.

**Time:** 30 to 40 minutes.

## Why it matters

A calendar that only holds meetings has no room for dinner, the school run or a walk, so those quietly lose every week. Today you tell your butler what a good week looks like. From now on, every Sunday at 18:00, he proposes next week for you, and nothing lands in your calendar until you say "apply".

## Today

1. **Create a calendar called Butler** in Google Calendar. Your bot will tell you where to click. This is where it writes its plans. Your own calendars stay yours. Think of it as giving the butler his own pantry instead of letting him rearrange yours.
2. **Say yes to your bot's morning message** (or *"I'm doing the 7-day challenge, day 6"*). Want the optional extra? Tell it *"add Context Bootstrap"* (more below).
3. **Give it read access to your other calendars.** Work, personal, family, the school one. It reads them all and writes to none of them.
4. **Tell it your week shape**, one question at a time: working hours, family rhythms, **reset length** after demanding blocks (default 15 minutes), lunch, movement, me-time, and the **maximum demanding blocks per day** (default 2). Be honest. "Nine demanding blocks" is not a rhythm, it's a cry for help.
5. **Read your first weekly build and say "apply".** It picks 3 to 5 outcomes from your ledgers, places focus blocks around your fixed commitments, and protects lunch, resets, family time and a real finish time. Holds appear in the Butler calendar only after your "apply".
6. **Approve the Sunday routine.** Every Sunday at 18:00: next week's proposal, ending with "reply apply". Corrections welcome. Silence means nothing gets written.

## Optional extra: get back into a block

Say *"add Context Bootstrap"* during today's step (or attach `context-bootstrap-skill.md` if you want the full skill) and your bot learns a habit: say *"start [matter]"* at the beginning of a work block and it rebuilds what you were doing, where you left off and the first thing to touch. No more "what was this file again?" Worth it if you switch between clients a lot. Skip it if you don't.

When the day goes sideways, say *"my day changed"*. It replans the rest of today only, and tells you honestly what no longer fits.

## Done when

Your bot has sent its "Day 6 done" block: Butler calendar writable, other calendars readable, week shape saved, first week proposed (and ideally applied), Sunday 18:00 build scheduled.

## Proof to post

A zoomed-out screenshot of next week with the Butler calendar showing. Blur every event title. Colours and shapes tell the story; the titles are nobody's business.

## Snags

- **The bot says it can't create calendars.** Expected. You create Butler yourself; it finds it.
- **Butler exists but the bot can't see it.** It's in a different Google account. Create it in the account your bot uses, or share it with that account.
- **The plan is overstuffed.** *"Update my week shape: max 1 demanding block, 20-minute resets."* Then *"propose next week again."*
- **It wrote to your work calendar.** Stop. Move or remove the event yourself, then *"re-read your calendar rule."*
- **Sunday 18:00 doesn't suit.** *"Move the weekly calendar build to Monday 07:00."*

## Check in: #Day6

Comment on your build log: *#Day6. Max demanding blocks: ___. Reset: ___ min. The block I'm most glad to see protected: ___.* Plus the blurred screenshot. Once you've actually used a reset, tell us what you did with it in **Presence log**.

**Resources:** `context-bootstrap-skill.md` (optional)


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Day 7: Hand over the keys

Six days of parts. Today it becomes one system: a chief of staff you talk to, a ledger per matter that stays true with your nod, and a briefing every morning that reads from them. Plus a few bonus toys. I'd get emotional, but I'm British in spirit.

**Time:** 30 to 45 minutes, plus tomorrow morning's coffee.

## Why it matters

A system you don't trust is a system you check, and checking is what we're trying to get you out of. Today you agree exactly how much your butler may do on his own, and how he earns more. Then you can put the phone face down at dinner and mean it.

## Today

1. **Say yes to your bot's last morning message** (or *"I'm doing the 7-day challenge, day 7"*). When you finish, it congratulates you and switches the morning messages off.
2. **Make it your chief of staff.** One bot you talk to about everything, from the app on desktop and phone, or Slack. Teammate bots from Day 2 report into the same ledgers; your chief of staff briefs you. Any bot still "proposed": create it from its brief, or let it go.
3. **Agree the trust ladder.** Read, then draft and propose, then act in its own space, then act outward only under a rule you've written. It earns each rung over two weeks. You promote; it doesn't. Auto-applying the nightly ledger pass is a promotion too, one matter at a time.
4. **Let it point your briefings at the ledgers.** The 07:50 morning briefing now reads every sheet and tells you how many proposals are waiting. The 21:00 heads-up stays short.
5. **The bonus round. All optional.** Say yes or no to each:
    - **Meeting prep** before named calls, and a **deliverables list** after calls. Follow-ups come as draft cards. You send.
    - **Mac full-screen nudges** when each Butler block starts, if you use a Mac.
    - **Home Assistant**: its address and a long-lived token, stored as a secret. Never paste the token in chat. One read-only test; it changes nothing without asking.
    - **A wearable recorder**, so promises you make out loud turn up as proposals in the right ledger.
6. **Run the self-check, read the recap, post your win.** Your bot checks everything from Days 1 to 6 actually works, warns you about any active matter still without a ledger, tests that real things made it into your sheets, gives you the full recap and drafts your post. You add the screenshot and press post. Yes, you. Draft before send, remember?

## The end state

- **K matters, K ledgers.** Every active matter in `matters.md` has a live ledger; anything not ready sits under Later. Each sheet is the state of that part of your life. Every night your butler proposes updates from evidence; you apply them.
- **One chief of staff** who knows all of it, reachable from your pocket, with teammate bots for the busy matters if you want them.
- **A morning briefing and an evening heads-up** that work from the sheets, not from vibes.
- **A week proposed every Sunday**, resets included.
- **The sheets capture everything relevant.** When something real happens and isn't in a sheet, that's a hole, and your bot's job is to find it.

The architecture diagram shows how it fits together: [how it fits together](../images/day-7-architecture.png). It's simpler than it looks. Most good butlers are.

## Done when

Your bot has sent its "Day 7 done" block: chief of staff confirmed, trust ladder written, briefings reading the ledgers, bonus items on or skipped, self-check with no open gaps, onboarding complete, win post drafted. And you've posted it.

## Proof to post

A screenshot of a morning briefing, with names, clients, figures and event titles blurred. Required. Your bot can't attach it, which is the one thing I like about this rule.

## Snags

- **The briefing only talks about the calendar.** It isn't reading the ledgers. *"Re-run the Day 7 briefing step: point the briefings at the ledgers."*
- **The self-check says FIX.** Fix in day order. Day 3 before Day 5. Ask your bot *"explain this FIX and walk me through it"*. Still unclear? Post the FIX line in **Stuck & broken**.
- **You pasted the Home Assistant token in chat.** Revoke it in Home Assistant, make a new one, use the secret prompt. No harm done if you're quick.
- **The recorder catches everything.** *"Only suggest clear 'I will…' commitments or ones with a date."*
- **"Can it just auto-apply now?"** In two weeks, one matter at a time, with evidence. Day 7 is the start of trust, not the end.

## Check in: the last step (#Day7)

Post in **My bot did it**. Title: *Built: [bot name] in 7 days*. Start the body with #Day7. Your bot drafts it to this outline; you add the screenshot:

- What your setup does now, in 3 to 4 lines (matters, ledgers, routines, briefing)
- How many matters and live ledgers, and which tools feed them (generic names)
- Where you talk to your chief of staff: the app or Slack
- One thing it caught that you'd have dropped (no names, no figures)
- What broke and how you fixed it
- **Required:** a screenshot of a morning briefing, with names, clients and figures blurred

No screenshot, no unlock. I'm strict, not unkind.

Your 7 days are done the moment your bot sends its Day 7 recap; all of it runs in your own bot, and nothing waits on me. The rest of the Classroom is different: to unlock it, post your build recap. I read the post and unlock the rest of the Classroom for you. That's the only thing my reply gates.

**Resources:** [how it fits together](../images/day-7-architecture.png)


> Course page. Your assistant runs the matching file in `onboarding/`, not this page. On Claude or ChatGPT, "your bot" is the assistant where you installed this pack. The original Grok Bot template is still here: https://x.ai/bot/gnwO_M9gMWTJ8xhUzjFi4

# Show us

You did it. Seven days ago your promises lived in your head, which, with respect, is not a filing system.

**Time:** 10 minutes, plus however long you spend admiring your briefing.

## Why it matters

A setup only helps if it becomes a habit. The next two weeks decide whether your butler fades into another app you used to open, or becomes the quiet centre of your week. Keep it boring: read the briefing, apply the proposals, approve the Sunday build, put the phone down.

## What you built

- A butler from the Agentic Butler template, with a charter: it drafts, you press send
- Your matters, each with its own ledger, kept true by nightly proposals you apply
- Teammate bots for the busy matters, if you wanted them, each sending nothing on its own
- Your tools connected, each at the access level you chose
- A morning briefing and an evening heads-up that read from your sheets, not from vibes
- A week proposed every Sunday around your real commitments, reset time included

## Today

1. **Post in My bot did it.** Title: *Built: [bot name] in 7 days*. Same outline as Day 7 (your bot drafted it):
    - What your setup does now, in 3 to 4 lines (matters, ledgers, routines, briefing)
    - How many matters and live ledgers, and which tools feed them (generic names)
    - Where you talk to your chief of staff: the app or Slack
    - One thing it caught that you'd have dropped (no names, no figures)
    - What broke and how you fixed it
    - **Required:** a screenshot of a morning briefing, with names, clients and figures blurred
2. **I'll unlock the rest of the Classroom.** Your 7 days are already done; they ran entirely in your own bot. The rest of the Classroom opens once I've read your post: I reply with one thing that's working and one thing I'd tighten, and unlock it for you. Meanwhile, carry on with your butler as normal; nothing else waits on me.
3. **Bring your questions to the community.** Something broke, or you're not sure what to try next? Post it in **Stuck & broken** with what you tried and what happened. Something always breaks. That's not failure, that's week two.
4. **Share a recipe.** Found a routine, a skill or a prompt that earns its keep? Post it in **Recipes** with "Recipe:" in the title. Strip personal data first. Your bot can do that too.

## What's next

- **Week two is maintenance, not more building.** Read the morning proposals and apply or correct them. Trust grows from corrections, not from adding a seventh matter.
- **Raise trust slowly.** When a matter's nightly proposals have been right for two weeks, you may let that one auto-apply. Tell your bot: *"promote [CODE] to auto-apply."* One matter at a time, under a written rule.
- **Add when it's quiet, not when it's loud.** A second round of ledgers, another teammate bot, the bonus bits you skipped: *"resume onboarding"* picks them up.
- **The morning challenge messages have stopped.** Your bot switched them off after Day 7. The briefing at 07:50 carries on.
- **Pause is a feature.** Holiday, a sick week, a launch: *"pause"*. *"resume"* when you're back.
- **Tell us what you did with the time.** **Presence log** is for that. No tech required. That was the point all along.

## Done when

Your win post is up, with a blurred briefing screenshot, and you've picked one week-two habit.

## Proof to post

The win post itself. Check the screenshot once more before you press post. Then once more.

## Snags

- **You stopped reading the briefing.** It's too long or too early. *"Shorter, and at 08:15."*
- **The proposals pile up.** *"Apply all of CLA"* is allowed. So is reading only the counts.
- **The Sunday build feels wrong.** *"Update my week shape."* Your week changed; the shape can too.

## Check in: #Finish

Comment on your build log one last time: *#Finish. The habit I'm keeping: ___. My week-two step: ___. Phone time I think I got back this week: ___.*

Well done. I mean it. Mostly.
