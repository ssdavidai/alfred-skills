---
name: research-interview-prep
description: "Used before a research or customer-discovery interview to build a one-screen brief from the candidate's notes, the outreach thread and the study's research questions. Read-only; research, not sales."
license: MIT
---

# Research interview prep

A brief the interviewer can read in two minutes before a short research call.

## Inputs
- The interview (name, date/time with time zone) from the tracker or the outreach reports.
- The candidate's research row (role, practice, AI or tool evidence, why interview, screening gaps, public sources) and the personalization hook used in outreach.
- The study's research questions and promises (e.g. "research only, no pitch", "participants get the report").

## Steps
1. **Confirm the slot**: date and time in the owner's timezone and the interviewee's local time if known. If the time is uncertain, say so.
2. **Profile** in 3–4 bullets from the row only: role, practice and size, client model, notable workflow or tool evidence. Mark anything not in the sources as unknown.
3. **Pick 5 questions** from the research questions that this person is best placed to answer, ordered for a 15-minute call, plus one opener based on the hook and one closer (referral ask, report promise).
4. **Gaps to probe:** the row's screening gaps phrased as quick checks.
5. **Reminders:** research only; don't pitch; promised the report; ask permission before quoting by name.
6. **Output:**
   ```
   Interview prep: <Name> — <date time, owner tz> (<local>)
   Who: …
   Why them: …
   Opener: …
   Questions (15 min): 1… 5…
   Probe: …
   Close: referral? · report promised ✔
   ```

## Never
- Contact the interviewee or change the calendar.
- Add facts that are not in the sources; never invent achievements.


---
name: research-interview-synthesis
description: "Used after a research interview transcript or recap is available to map it to the study's questions (themes, quotes, surprises, follow-ups), or to roll several interviews into emerging findings. Anonymized."
license: MIT
---

# Research interview synthesis

Turn interviews into evidence the report can stand on.

## Inputs
- A transcript or recap the assistant is allowed to read (pasted, linked doc, or an allowed recording source). If none exists, report "no transcript" and stop for that interview.
- The study's research questions.
- For cumulative mode: earlier syntheses (in a synthesis doc).

## Per-interview mode
1. **Participant profile** (anonymized): role, practice size, number of clients, tool stack.
2. **Answers by research question**: for each question that came up, 1–3 bullets with a short supporting quote and timestamp if available. Mark unanswered questions.
3. **Themes**: workflows, pain points, workarounds, what they built themselves, what they pay for, what they wish existed.
4. **Surprises / contradictions** with earlier interviews.
5. **Follow-ups**: anything promised to the participant (e.g. the report), referrals offered, questions to add to the guide.
6. Leave out personal asides entirely.

## Cumulative mode
1. Count interviews covered and list them anonymized (P1, P2 …).
2. **Emerging findings**: each finding with how many participants support it and the best quote; separate strong (3+), emerging (2) and single signals.
3. **Thin questions**: research questions with little evidence so far, and which upcoming interviewees could fill them.
4. **Report outline progress**: sections that now have enough evidence.

## Output
```
Synthesis: <P# · role> — <date>   (or: Cumulative — <n> interviews)
By question: …
Themes: …
Surprises: …
Follow-ups: …
```

## Rules
- Quote participants by name only if the owner confirms they agreed; otherwise anonymize.
- Never invent quotes; paraphrase is marked as paraphrase.
- Work content only.


---
name: itemize
description: "Turns a plan into an epic and child-issue draft, one atomic issue per phase, sequenced and cross-referenced. Use when the owner says itemize this or asks to break a plan into issues. Files nothing."
license: MIT
---

# Itemize — plan → atomic, sequenced units

Turns a plan into a **draft** that the owner (or their coding agent) files. The bot files nothing itself.

## What "atomic" means
- Every single unit of work is one item, not bundled.
- Properly cross-referenced: each item links to its parent, dependencies and related items.
- Labeled: type (feat/fix/chore/docs), area (package/lane), size (S/M/L) if useful.
- Dependencies marked: which items block which; ordered, it looks like a waterfall.
- Properly sequenced: phase 0 / phase 1 / phase 2, explicit ordering.
- Planned for maximum parallelism: parallel-safe items flagged; items that must sequence say why.

## Steps
1. **Read the plan** from wherever it lives: the conversation, a linked doc, an issue body (read-only), a previous list. Don't decompose blind; ask if the plan is unclear.
2. **Decompose** into units that are each: one discrete piece of work (typically ≤200 LOC or one written artifact), independently verifiable (a concrete done test), owned by one lane/package, and small enough for one agent session. Split big units; merge trivia into an adjacent unit.
3. **Sequence:** Phase 0 = shared foundations (migrations, contracts, schemas, gates); Phase 1+ consumes earlier phases. Within a phase mark parallel-safe vs must-sequence (provider → consumer). For each unit: blocks / blocked by.
4. **Labels:** if a target repo is named, read its existing labels and reuse them; don't invent new ones unless the owner asked.
5. **Produce the draft**:
   ```
   EPIC: <name>   (target repo: <owner/repo or "local task list">)
   Phases: 0 → N

   [P0-1] <title>  labels: <…>  size: S
     Done when: <test>
     Blocks: P1-2, P1-3   Blocked by: —   Parallel-safe: yes
   …
   ```
   Then a filing checklist the owner can hand to their coding agent: create the epic, create children in order with "Part of #<epic>", then back-fill blocks/blocked-by numbers and tick-boxes in the epic.
6. **Confirm:**
   ```
   Itemized into N units across M phases.
   - Phase 0: <n> units (foundations, sequenced)
   - Phase 1: <n> units, <k> parallel-safe
   Draft ready to file in <repo>; nothing was created.
   ```
   Then stop. Do not start executing.

## Pitfalls
- Never create issues, labels or epics yourself from a cloud/team assistant.
- Don't bundle small units into "misc fixes". Don't write "and other tasks": every child is explicit.
