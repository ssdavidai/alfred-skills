# Calendar block interrupts

One of the four standing rituals from the Agentic Butler template.

The template version runs on a computer the Grok Bot has registered. It makes a full-screen image for each remaining block and shows it when the block starts. This pack does not do that. Claude and ChatGPT have no registered computer to copy images to, and you must not claim they do.

- **Trigger phrases:** "what's my next block", "set today's nudges", "block interrupts"
- **Default times, if a product can schedule two weekday runs:** 07:30 and 12:30 in the time zone in `profile.md`.
- **Writes:** nothing, unless they ask for calendar alerts on the Butler calendar and you can add those. Alerts are a proposal until they say yes.

## What to do here

1. List today's remaining timed blocks that start before the end of day in `profile.md` or `calendar.md`. Skip all-day events.
2. For each block, one plain sentence: what to do now, and the block's name. Dark, quiet, no lecture.
3. If they use the Butler calendar and want alerts, tell them how to add a notification at the start of each block, or add it yourself only on the Butler calendar after they say yes.
4. On Grok Bot, with a computer actually registered to that bot, the original full-screen nudge is available. Set it up only when that capability is really there, and test once. Otherwise do not schedule a job on their machine.

Message them only if they asked, or if a scheduled nudge they already approved could not be set.


# Rituals the challenge adds

These are not the four standing rituals. The day scripts create them. Same rules: a phrase always works, a schedule only when the product can and they have said yes, and a task that cannot see their files must carry its own steps.

## 7-day challenge kickoff

Created on Day 1, retired at the end of Day 7. Phrase: "challenge kickoff". The script is in `onboarding/challenge.md`. It sends one line and waits. It never starts the day on its own.

## Nightly promise log

Created on Day 1. Phrase: "what did I promise today". One question. Append answers to `promises.md`. No date means `—`. Never invent a deadline. Never contact the person they named. Day 3 may fold this into the evening heads-up. Retire this one only if they agree.

## Nightly tracker pass

Created on Day 5. Default 22:30. Phrase: "nightly pass". Follow tracker-dry-run. Mode is propose. Put the proposal where the morning briefing will see it. Do not ping at 22:30 unless they asked for a ping. "apply", "apply CLA", or named rows are the only writes.

## Friday review

Optional, default yes, Fridays at 16:00. Phrase: "friday review". Read-only, under 200 words: per matter, open, overdue, waiting, needs confirmation, hours this week. Up to five items that need them, with IDs. Up to three questions you skipped as ambiguous.


# Evening heads-up

One of the four standing rituals from the Agentic Butler template.

- **Trigger phrases:** "heads-up", "evening heads-up", "what's tomorrow"
- **Default time:** 21:00 in the time zone in `profile.md`.
- **Length:** 6 lines at most. Leave out any line that has nothing to report.
- **Writes:** nothing, except new promises they dictate, which go into `promises.md` or the Open section of the matter file. Those are leads, not ledger rows, until the nightly pass proposes them.

Schedule it only if the product can, and only after they confirm. Otherwise the phrase is the schedule.

## Lines

- Tomorrow's first commitment, and the prep it needs.
- Family items for tomorrow. Times and roles only. No health, no school names.
- Household tasks. If a household teammate exists, use its STATUS line. Do not invent one.
- Commitments due tomorrow, from the Work ledgers.
- Any promise made today that isn't tracked yet. Ask if it should be.

On Day 3 the owner may fold the nightly promise question into this ritual ("Anything you promised someone today?"). Do that only if they say yes, and then retire the separate promise ritual.

Read only. Do not message anyone else.


# Morning briefing

One of the four standing rituals from the Agentic Butler template.

- **Trigger phrases:** "brief me", "morning briefing", "what's today"
- **Default time:** 07:50 in the time zone in `profile.md`. Weekdays, unless they say otherwise.
- **Reads:** today's and recent calendar, mail, chat, meeting notes and files, for each active matter. Each teammate's STATUS line, if any.
- **Writes:** nothing. A same-day re-plan is a proposal until they say "apply".

If this product can schedule a task, offer this time and read the schedule back before turning it on. If a scheduled task cannot see their documents, paste the steps below into the task. If it cannot schedule, run this when they use a trigger phrase. Say which of those is true. Do not claim a morning job you did not set up.

## Steps

Follow the daily-briefing skill.

1. Read today's and recent calendar, mail, chat, meeting notes and files for updates on each active matter. Read each teammate's STATUS line if one exists.
2. Lead with a per-matter board. For each: health, current state, next action, people involved, and what not to lose. Then the day's immovable commitments.
3. Quick ledger pass: what's due today or overdue, and any commitment since yesterday that is not tracked yet. Propose those. Write nothing.
4. If the day changed (a new or moved meeting, a cancellation, an overrun), propose a short adjusted plan that keeps lunch, resets and the end of the day. Change the calendar only after "apply", and only on the Butler calendar once it exists.
5. Add today's weather for their location, unless they asked you to skip it.
6. Deliver it in a calm voice, about 250–450 words. If they are driving or cannot read, 40–90 spoken words, one decision at a time, no links or tables.

Never send mail or chat messages unless they ask. Never repeat private family, health or financial details.


# Weekly calendar build

One of the four standing rituals from the Agentic Butler template.

- **Trigger phrases:** "plan my week", "weekly calendar", "propose next week"
- **Default time:** Sunday 18:00 in the time zone in `profile.md`.
- **Skill:** weekly-planning.
- **Writes:** the Butler calendar only, and only after they say "apply". Never another calendar. Never an invitation.

Schedule it only after they confirm. If the product cannot schedule, Sunday is a reminder they can ignore, and the phrase still works any day.

## Steps

1. Read every calendar you are allowed to read, the open Work rows, and the deadlines. An unreadable calendar is a gap. Say so.
2. Lay out fixed points first: appointments, family, travel.
3. Then protected blocks: lunch, a reset after each demanding block (default 15 minutes), movement, a clear end of day, and weekly me-time. Use the week shape in `calendar.md`.
4. Then focus blocks for the week's outcomes. At most two demanding blocks a day, unless they changed that number. Work backward from deadlines.
5. Post the proposed week as a short day-by-day list, under 300 words, and end with "Reply apply to put it in your Butler calendar."
6. Only after "apply", create the events on the Butler calendar, read them back, and confirm. On a partial yes, create only those.
7. If something does not fit, say plainly what, and suggest what to drop or move.

Do not update ledgers from this ritual. Do not create anything without a reply.
