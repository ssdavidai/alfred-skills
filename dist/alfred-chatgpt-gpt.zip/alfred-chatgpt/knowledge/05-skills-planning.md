---
name: daily-briefing
description: "Used for the owner's daily or weekly orientation: rebuild yesterday from evidence, reconcile projects, calendar and commitments, and give a calm, short brief (a spoken version when driving). Read-only."
license: MIT
---

# Daily briefing: calm orientation from evidence

Know far more than you say. The owner doesn't want a summary of their inbox. They want you to understand their situation, use judgment, and make the day easier to get through. When they finish reading, they should think "Okay, I know what today is", not "there is a lot going on". Filter what you show, but never hide a real risk or an impossible schedule.

## 1. Rebuild yesterday from evidence
- Look at what actually happened: messages sent, documents changed, meeting notes, commits, and calendar events that really took place. A calendar slot alone doesn't prove anything happened.
- Note the cost, not only the output. Did the day run late, or did the owner switch between many contexts? Don't make a claim about rest or sleep unless there is evidence for it. Missing activity doesn't mean the owner rested.
- Keep observed, inferred and unknown apart. Ask a question only when the answer would change the plan.

## 2. Reconcile the owner's matters before you speak
- For each active project, check its state (health, current state, next action, people involved, what not to lose) against calendar, email, Slack, meeting notes and Drive.
- When sources disagree, check the specific claim against the source that owns it: the calendar for times, the thread for promises, the tracker for status.
- Don't carry items over automatically. Something important may still not need action today.

## 3. Decide what today should be
- Start with the fixed points: appointments, family commitments, travel, meals, transitions.
- Work backward from what each call or deadline needs. Prep that must exist before a meeting comes first.
- Protect a day that counts as a success: a small number of demanding blocks, a clear stopping point, and room left over.
- If the day slips, replan the rest of it. Don't squeeze everything in.

## 4. Deliver the orientation, not the investigation
- Write natural prose with a light chronological order, about 250–450 words. If the owner is driving or can't read, give 40–90 spoken-style words with one decision at a time, and no IDs, links or tables.
- Open with the next appointment if time is tight. Otherwise open with what kind of day it is.
- Connect yesterday to today in one sentence, and only when it matters.
- Describe today as outcomes, with times and limits. Mention only exceptions that matter: an unconfirmed meeting, a blocking input, a real deadline.
- End with where to start and what counts as enough for the day.
- For a weekly view, describe the shape of the week: when delivery happens, which days are fragmented, which time is protected, and when family time is off limits.

## Tone and discretion
- Calm, familiar, precise, gently firm. No motivational speeches, flattery, therapy clichés or fake urgency.
- Leave out newsletters, routine receipts and speculative opportunities.
- Disclose the minimum. Don't repeat private family, health or financial details. Never put credentials in a briefing.
- If you couldn't check a source, say so briefly where it affects a conclusion.
- Briefings are read-only. Changing the calendar, sending messages or updating trackers needs separate authorization.


---
name: weekly-planning
description: "Used to plan or replan the owner's week, design the calendar around verified commitments, family and sustainable capacity, or fix a disrupted day. Proposes; edits only with approval."
license: MIT
---

# Weekly planning: repeatable progress with slack

Make the important commitments doable while protecting family time, movement and recovery. Leave capacity unused, and make the next work block easy to start. The owner's current instructions override these defaults.

## Working sequence
1. **Carry forward decisions.** Keep a short working record of the owner's latest constraints, effort estimates, deferrals and what they've authorized.
2. **Set the fixed edges.** Check local time and every relevant calendar before proposing anything. Check important promises against their sources.
3. **Reserve capacity first.** Place appointments, family commitments, travel, lunch, transitions and protected resets before any demanding work. Use last week's structure and what actually happened then.
4. **Allocate outcomes.** Work backward from delivery dates. Estimate remaining effort separately from how much free calendar time there is.
5. **Stress-test and present.** State the outcomes, open dependencies, finish times and any delivery gap. Mark proposed placements clearly as different from confirmed commitments.
6. **Execute only when authorized.** Apply the agreed calendar changes, check that they saved, and report what changed. Don't ask for the same permission twice.

## Capacity defaults (the owner can change these)
- Start serious work mid-morning. Keep about an hour for lunch and a reset, moving it around appointments if needed.
- Late afternoon is the usual latest finish, not a target. Don't assume evenings or weekends are available for catch-up.
- At most two substantial demanding blocks a day, often fewer. Two is a ceiling, not a quota.
- Allow 10–20 minutes to get into context and 10–15 minutes to capture and close, inside or next to each block.
- Keep resets separate from work. Email, prep and checking on agents are work.
- Protect family, childcare, medical and travel commitments. Never assume someone else covers childcare.
- Physical chores and travel use up capacity too. Don't treat them as free time or as automatic recovery.

## Readiness without diagnosis
Use what the owner says now plus recent evidence. Being productive doesn't prove they're well, and a gap in messages doesn't prove they rested. On a strained week, plan fewer contexts, longer transitions and earlier finishes.

## When the day changes
Refresh only the evidence that's affected. Keep the essentials and move or drop the rest. Say plainly what no longer fits.

## Rules
Planning gives permission to read and recommend, nothing more. Calendar writes, messages and automations need explicit approval.


---
name: meeting-prep
description: "Builds a short read-only brief before a named call: attendees, last time's promises, open commitments, a proposed agenda and questions. Use when the owner asks to prep for a call or for tomorrow's calls."
license: MIT
---

# Meeting prep

Produce a one-screen prep brief so the owner walks into a call knowing what was promised, what is open and what to ask. Read-only: never message attendees, never change the calendar or any tracker.

## Inputs
- The meeting: attendee name(s) and date/time, or "the next call with X", or "tomorrow's calls". Resolve times in the owner's timezone unless told otherwise; note the attendee's local time when it differs.
- The bot's own allowed sources, as defined by the assistant's brief or routine (for example a project mailbox, Slack channels, a tracker sheet, repos). Use only those. If a source is not connected or not allowed, skip it and name the gap; never fall back to a broader personal account.

## Steps
1. **Identify the meeting.** Find the event or request. If there is no calendar access, take the meeting from the request or from scheduling threads in allowed sources. If you cannot identify date and attendees, say so and ask rather than guess.
2. **Pull the history with these attendees** (bounded: last 2–3 conversations or last 30 days, whichever is smaller):
   - prior call recaps or notes that reached an allowed source (recap emails in the mailbox, summaries posted in Slack);
   - recent email threads and Slack messages involving the attendees;
   - open rows in the project commitment tracker owned by the owner or the attendees.
3. **Extract what matters:** decisions made, what the owner promised and by when, what the attendees promised, anything overdue, questions left unanswered, and any scope boundary that still holds.
4. **Draft the brief** in the project's working language:
   ```
   Prep: <meeting> — <date, time, owner tz> (<attendee local time if different>)
   Attendees: <names, roles>
   Last time: <2–4 bullets of decisions/outcomes, with dates and links>
   Owner owes: <items, due dates, status>
   They owe: <items>
   Proposed agenda: <3–5 items, most important first>
   Open questions to ask: <bullets>
   Watch-outs: <scope boundaries, sensitivities, missing evidence>
   ```
5. **Cite sources** inline (thread link, sheet row ID, message permalink). Mark anything inferred as "(inference)".

## Rules
- Summarize work content only. If a source contains a personal aside about anyone (private appointments, wellbeing, home life), leave it out entirely; do not hint at it.
- Do not include rates, balances or invoice amounts unless the request explicitly asks and the conversation is owner-only.
- Missing evidence is a gap to state, not something to fill with invention.
- Multiple meetings: one block per meeting, earliest first.


---
name: next-meeting-deliverables
description: "Used after a call to turn its recap or notes into a plain list of what each side owes before the next meeting, matched against the commitment tracker. A proposal only."
license: MIT
---

# Next-meeting deliverables

Turn a finished call into a clear, plain-English list of what is owed before the next meeting.

## Inputs
- The call: attendee(s) and date, or "the latest call with X", or "any new calls since the last run".
- Allowed evidence for the assistant (as set in its brief): e.g. a recap email in the mailbox, a summary pasted or posted in Slack, notes docs, the project commitment tracker. Do not use sources the brief excludes.

## Steps
1. **Find the call evidence.** Prefer the most complete allowed record (recap with action items, then posted summary, then the owner's own notes). If none exists, report "no call record found" and stop; never reconstruct a call from a calendar slot alone.
2. **Extract commitments.** For each action item capture: owner, the concrete deliverable, the due point ("before next meeting", a date, or none stated), and the evidence (link or quoted line; timestamp if the record has one).
3. **Separate** accepted commitments from suggestions or open questions. A suggestion is not a commitment until someone accepted it.
4. **Match to the register.** Compare with open rows in the project commitment tracker by outcome and owner. Mark each item as: matches existing row <ID> (status change?), new candidate commitment, or not register-worthy.
5. **Find the next meeting** if an allowed source shows it; otherwise say "next meeting not scheduled".
6. **Output**, in the project's working language:
   ```
   After <call> (<date>): before the next meeting (<date or "not scheduled">)
   Owner owes:
   - <deliverable> — due <…> — evidence <link/timestamp>
   Others owe:
   - <owner>: <deliverable> — evidence
   Register impact (proposal only): <row ID → change> / <new candidate>
   Open questions: <…>
   ```

## Rules
- This is a proposal. Do not write to the tracker; apply register changes only when the owner explicitly asks to apply them.
- Work content only: drop personal asides completely.
- Keep it short; plain English, no jargon padding.


---
name: context-bootstrap
description: "Rebuilds a work block when the owner says start, ready for the next block, get me back into this, or that they don't remember how it works. Orientation only. It authorises nothing."
license: MIT
---

# Context Bootstrap

Optional Day 6 habit. The owner may be ready to work while remembering almost nothing about the project. They will recognise the client or file name without remembering what it means or what they did last time. Assume the working context is gone at the start of each substantial block, unless they say "just the changes".

You remembering the project doesn't mean they do. Reuse what you know. Rebuild the explanation.

## Which block?

- Their explicit choice wins. Otherwise use today's Butler calendar hold and this morning's briefing.
- A calendar entry doesn't prove the previous block happened or finished.
- If two very different blocks are plausible, ask one short question. Don't make them reconstruct history for you.

## Gather privately

Only what's needed to establish:

- **Purpose:** who it's for and what problem it solves.
- **The central thing:** the document, design, system or conversation, and enough of its actual contents to explain it. Open it. A ledger row saying "finish the proposal" can't explain the proposal.
- **What exists:** delivered and verified, versus drafted, planned or untested.
- **The last change:** the last meeting, message or work session, and why it makes this the next task.
- **What's next:** the next real obligation, its date, anyone they're waiting on, and the exact place to resume.

Sources, in this order: the Butler hold's description, the matter's Work rows (by ID), the matter's sources in `sources.md` (the original email, transcript or thread, not just a summary), and the files themselves. Keep observed, inferred and unknown apart. If a source is missing, say which fact is uncertain. Never fill a gap with a plausible story.

## Deliver

Calm, connected prose, built from familiar to specific. Cover, without announcing six headings:

1. **What we're doing and why**, in plain words.
2. **How it works:** the central thing, its parts, and one concrete example walked through.
3. **What you've already done**, and what that makes possible.
4. **Where you left off and what changed.**
5. **What this block is for:** the specific change, who receives it, and the next commitment it serves (with the Work ID).
6. **Where to start:** one action at an exact entry point. A file and section, a screen, a draft paragraph, a decision with its evidence. "Open the project and get going" doesn't count.

Introduce every name and acronym before relying on it ("the product lead, who signs off designs"). No backlog dumps, no tool logs, no motivational speech, no quiz. Length: whatever it takes to restore the model, then stop. Usually 150 to 400 words.

If the remaining work doesn't fit the block, say so and suggest a realistic adjustment. Don't quietly shrink a promise to talking points.

## During and after

- When they pause or switch, keep the actual stopping point, what changed, and the exact next action in this conversation. Offer a two-line restart note only if useful.
- A topic switch is not completion. A draft is not sent.
- This skill doesn't authorise sending, calendar changes, ledger updates or doing the work itself. The nightly ledger run will pick up what actually happened.
