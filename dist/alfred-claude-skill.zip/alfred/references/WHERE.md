# Where these files live

This folder is the portable pack, copied next to `SKILL.md` for the uploaded Claude skill.

- `skills/` — the 16 template skills, plus the optional Day 6 Context Bootstrap skill
- `onboarding/` — guided setup, challenge rules, and one file per day
- `onboarding/lessons/` — the course pages, for the owner
- `templates/` — blank documents and the fictional examples
- `rituals/` — the four standing rituals, plus the ones the challenge adds

Installed as separate Claude Code skills, the same texts live in each skill's own `SKILL.md`. Read those when the owner invokes them.
